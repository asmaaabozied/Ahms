<?php

return [
    'name' => 'News'
];
